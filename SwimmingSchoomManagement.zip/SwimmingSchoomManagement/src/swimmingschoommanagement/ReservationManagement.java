package swimmingschoommanagement;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class ReservationManagement {

    private Scanner scan;
    private Swimmer swimmer;
    private int swimmingId;
    private int swimmerId;
    private SwimmingTimeTable timetable;
    private SwimmingLesson lesson;
    private int reservationNo;
    private String reservationStatus;
    private List<ReservationManagement> reservations;

    public Swimmer getSwimmer() {
        return swimmer;
    }

    public void setSwimmer(Swimmer swimmer) {
        this.swimmer = swimmer;
    }

    public int getSwimmingId() {
        return swimmingId;
    }

    public void setSwimmingId(int swimmingId) {
        this.swimmingId = swimmingId;
    }

    public int getSwimmerId() {
        return swimmerId;
    }

    public void setSwimmerId(int SwimmerId) {
        this.swimmerId = SwimmerId;
    }

    public SwimmingLesson getLesson() {
        return lesson;
    }

    public void setLesson(SwimmingLesson lesson) {
        this.lesson = lesson;
    }

    public int getReservationNo() {
        return reservationNo;
    }

    public SwimmingTimeTable getTimetable() {
        return timetable;
    }

    public void setTimetable(SwimmingTimeTable timetable) {
        this.timetable = timetable;
    }

    public void setReservationNo(int reservationNo) {
        this.reservationNo = reservationNo;
    }

    public String getReservationStatus() {
        return reservationStatus;
    }

    public void setReservationStatus(String reservationStatus) {
        this.reservationStatus = reservationStatus;
    }

    public List<ReservationManagement> getReservations() {
        return reservations;
    }

    public void setReservations(List<ReservationManagement> reservations) {
        this.reservations = reservations;
    }

    //create constructor
    public ReservationManagement(Swimmer swimmer, SwimmingTimeTable timetable) {
        reservations = new ArrayList<>();
        this.swimmer = swimmer;
        this.timetable = timetable;
        scan = new Scanner(System.in);
    }

    //create constructor
    public ReservationManagement(Swimmer swimmer, SwimmingLesson lesson, int reservationNo, String reservationStatus) {
        this.swimmer = swimmer;
        this.lesson = lesson;
        this.reservationNo = reservationNo;
        this.reservationStatus = reservationStatus;

    }

    //class reservation
    public void reserveClass() {
        String select;
        boolean validSelection = false;
        boolean availableSeat;
        boolean duplicateReservation;
        boolean validSwimmingId;
        boolean goPreviousAction;
        System.out.println("\nEnter one type that you want to view the timetable.");
        //take Swimming id from user to reserve class 
        while (!validSelection) {
            //display time table
            goPreviousAction = timetable.lessonTimeTable();
            if (goPreviousAction) {
                return;
            } else {
                System.out.println("\nEnter valid Swimming id from above list or enter any key to go back");
                //show information before take input
                System.out.print("\nEnter Swimming id : ");
                select = scan.nextLine().trim();
                //validation of valid input
                if (select.equalsIgnoreCase("back")) {
                    return;
                } else if (!select.matches("Swim@_\\d+")) {
                    System.out.println("Invalid choice: Please enter a valid Swimming id .");
                } else {
                    //change selected Swimming id into integer for validation
                    int class_id = Integer.parseInt(select.substring(7));
                    //get validation result
                    validSwimmingId = validSwimmingId(class_id);
                    availableSeat = classCapacity(class_id);
                    //print details if not valid class
                    if (!validSwimmingId) {
                        System.out.println("Invalid Choice : Swimming id does not exist");
                        //print error message if not available seat
                    } else if (!availableSeat) {
                        System.out.println("Invalid Choice : Seat not available in this clas");
                    } else {
                        validSelection = true;
                        swimmingId = class_id;
                        //take swimmer id input from swimmer
                        swimmerId = selectSwimmer();
                        duplicateReservation = duplicateReservation(swimmingId, swimmerId);
                        if (!duplicateReservation) {
                            //create swimmer and swimmingLesson object of selected swimmer id and swimming id
                            Swimmer swimmer1 = swimmer.getSwimmerByid(swimmerId);
                            SwimmingLesson lesson1 = timetable.getSwimmingLessonDetailsById(swimmingId);
                            reservationNo = reservations.size() + 1;
                            //store in reservation list
                            reservations.add(new ReservationManagement(swimmer1, lesson1, reservationNo, "Booked"));
                            timetable.seatModify(swimmingId, "Booked");
                            System.out.println("Class booked successfully");
                        } else {
                            System.out.println("Class already booked by the swimmer.");
                            reserveClass();
                        }
                    }
                    availableSeat = classCapacity(class_id);
                    if (!availableSeat) {
                        System.out.println("seat not available in this class enter another swimming id");
                    }
                }
            }

        }
    }

    //attend reserve class
    public void attendReserveClass(ReviewManagement review) {
        System.out.println("Enter one reservation no to attend or enter back to go to previous menu");
        String selectReservation;
        boolean validSelection = false;
        String status = null;
        int swimmerLevel = 0;
        int lessonLevel = 0;
        int registrationId = 0;
        if (!reservations.isEmpty()) {
            showReservations();
            while (!validSelection) {
                System.out.print("Enter Reservation No : ");
                selectReservation = scan.nextLine().trim();
                if (!selectReservation.matches("Reserve@_\\d+")) {
                    System.out.println("Invalid choice : Please enter valid reservation no");
                    return;
                } else {
                    reservationNo = Integer.parseInt(selectReservation.substring(10));
                    status = reservationStatus(reservationNo);
                    if (!validRegistrationNo(reservationNo)) {
                        System.out.println("Entered reservation no does not exist");
                    } else if (status.equalsIgnoreCase("Cancelled")) {
                        System.out.println("Entered class already Cancelled");
                    } else if (status.equalsIgnoreCase("Attended")) {
                        System.out.println("Entered class already Attended");
                    } else {
                        for (ReservationManagement reservation1 : reservations) {
                            if (reservation1.getReservationNo() == reservationNo) {
                                //show attended class details
                                showAttendClassDetails(reservationNo);
                                //get review after attended class
                                review.saveReview(reservationNo);
                                reservation1.setReservationStatus("Attended");
                                //modify capacity after cancel class
                                swimmingId = reservation1.getLesson().getSwimmingId();
                                timetable.seatModify(swimmingId, "Attended");
                                System.out.println("Reservation attended successfully");
                                //modify student level after attend higher class
                                swimmerLevel = reservation1.getSwimmer().getGradeLevel();
                                registrationId = reservation1.getSwimmer().getRegistrationId();
                                lessonLevel = reservation1.getLesson().getSwimmingLevel();
                                if (lessonLevel > swimmerLevel) {
                                    //modiify swimmer level
                                    List<Swimmer> swimmers = swimmer.getSwimmers();;
                                    for (Swimmer swimmer1 : swimmers) {
                                        if (swimmer1.getRegistrationId() == registrationId) {
                                            swimmer1.setGradeLevel(lessonLevel);
                                            break;
                                        }
                                    }
                                }
                                validSelection = true;
                                break;
                            }
                        }
                    }
                }
            }
        } else {
            System.out.println("reservation list is empty");
        }
    }

    //cancel reservation
    public void cancelReservation() {
        System.out.println("Enter one reservation no to cancel or enter back to go to previous menu");
        String selectReservation;
        boolean validSelection = false;
        String status = null;
        if (!reservations.isEmpty()) {
            showReservations();
            while (!validSelection) {
                System.out.print("Enter Reservation No : ");
                selectReservation = scan.nextLine().trim();
                if (!selectReservation.matches("Reserve@_\\d+")) {
                    System.out.println("Invalid choice : Please enter valid reservation no");
                    return;
                } else {
                    reservationNo = Integer.parseInt(selectReservation.substring(10));
                    status = reservationStatus(reservationNo);
                    if (!validRegistrationNo(reservationNo)) {
                        System.out.println("Entered reservation no does not exist");
                    } else if (status.equalsIgnoreCase("Cancelled")) {
                        System.out.println("Entered class already Cancelled");
                    } else if (status.equalsIgnoreCase("Attended")) {
                        System.out.println("Entered class already Attended");
                    } else {
                        for (ReservationManagement reservation1 : reservations) {
                            if (reservation1.getReservationNo() == reservationNo) {
                                reservation1.setReservationStatus("Cancelled");
                                //modify capacity after cancel class
                                swimmingId = reservation1.getLesson().getSwimmingId();
                                timetable.seatModify(swimmingId, "Cancelled");
                                System.out.println("Reservation cancelled successfully");
                                validSelection = true;
                                break;
                            }
                        }
                    }
                }
            }
        } else {
            System.out.println("reservation list is empty");
        }
    }

    //change reservation
    public void changeReservation() {
        String status;
        String selectSwimmingId;
        int previousSwimmingId;
        boolean validSelection = false;
        boolean validSwimmingId = false;
        boolean goPreviousAction;
        String selectReservation;
        System.out.println("Enter one reservationNo to change class or enter any key to go previous menu");
        //display booking details
        showReservations();
        if (!reservations.isEmpty()) {
            while (!validSelection) {
                System.out.print("Enter Reservation No : ");
                selectReservation = scan.nextLine().trim();
                if (!selectReservation.matches("Reserve@_\\d+")) {
                    validSelection = false;
                    System.out.println("Invalid choice : enter valid reservation no ");
                    return;
                } else {
                    reservationNo = Integer.parseInt(selectReservation.substring(10));
                    status = reservationStatus(reservationNo);
                    // validation of valid reservation no
                    if (!validRegistrationNo(reservationNo)) {
                        System.out.println("Entered reservation no does not exist");
                    } else if (status.equalsIgnoreCase("Cancelled")) {
                        System.out.println("Entered swimming id already Cancelled");
                    } else if (status.equalsIgnoreCase("Attended")) {
                        System.out.println("Entered swimming id already Attended");
                    } else {
                        validSelection = true;
                        //store previous swimming in for update capacity
                        previousSwimmingId = getReservationDetailByReservationNo(reservationNo).getLesson().getSwimmingId();
                        //select swimming id to change class
                        while (!validSwimmingId) {
                            goPreviousAction = timetable.lessonTimeTable();
                            if (goPreviousAction) {
                                return;
                            } else {
                                System.out.println("Enter one swimming Id from above list or enter any wrong key to go previous menu");
                                System.out.print("Enter swimming id : ");
                                selectSwimmingId = scan.nextLine().trim();
                                if (!selectSwimmingId.matches("Swim@_\\d+")) {
                                    System.out.println("Invalid choice : Please enter valid swimming id : ");
                                } else {
                                    //get swimminglesson id and swimmer id
                                    int newSwimmingId = Integer.parseInt(selectSwimmingId.substring(7));
                                    swimmerId = getReservationDetailByReservationNo(reservationNo).getSwimmer().getRegistrationId();
                                    //check swimmer level and swimminglesson level
                                    if (lessonLevel(swimmerId, newSwimmingId)) {
                                        if (duplicateReservation(newSwimmingId, swimmerId)) {
                                            System.out.println("Invalid choice : Entered swimming id already booked by you");
                                            validSwimmingId = false;
                                        } else {
                                            //get swimminglesson by id
                                            SwimmingLesson swim = timetable.getSwimmingLessonDetailsById(newSwimmingId);
                                            for (ReservationManagement reservation1 : reservations) {
                                                if (reservation1.getReservationNo() == reservationNo) {
                                                    reservation1.setLesson(swim);
                                                    reservation1.setReservationStatus("Changed");
                                                    break;
                                                }
                                            }
                                            //modify capacity after change class
                                            timetable.seatModify(previousSwimmingId, "Cancelled");
                                            timetable.seatModify(newSwimmingId, "Booked");
                                            System.out.println("\nReservation changed successfully");
                                            validSwimmingId = true;
                                        }
                                    } else {
                                        System.out.println("Invalid choice : Entered swimming id not for swimmer leve your current level is : " + swimmer.getSwimmerByid(swimmerId).getGradeLevel());
                                        validSwimmingId = false;
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    //show attend class details
    public void showAttendClassDetails(int reservationNo) {
        System.out.println("\n*==============================================*");
        System.out.println("|        Attend Class Details                                    |");
        System.out.println("------------------------------------------------");
        for (ReservationManagement reservation1 : reservations) {
            if (reservation1.getReservationNo() == reservationNo) {
                System.out.println("Reservation No: Reserve@_0" + reservation1.getReservationNo());
                System.out.println("Registration Id: Reg@_0" + reservation1.getSwimmer().getRegistrationId());
                System.out.println("Swimming id: Swim@_0" + reservation1.getLesson().getSwimmingId());
                System.out.println("Status: " + reservation1.getReservationStatus());
                System.out.println("Instructor: " + reservation1.getLesson().getSwimmingInstructor());
                System.out.println("Grade: " + reservation1.getLesson().getSwimmingLevel());
                System.out.println("Swimming Date: " + reservation1.getLesson().getSwimmingDate());
                System.out.println("Swimming Day: " + reservation1.getLesson().getSwimmingDay());
                System.out.println();
            }

        }
        System.out.println("*==============================================*");
    }

    //get reservation details by reservation no
    public ReservationManagement getReservationDetailByReservationNo(int reservationNo) {
        ReservationManagement reservation = null;
        for (ReservationManagement reservation1 : reservations) {
            if (reservation1.getReservationNo() == reservationNo) {
                reservation = reservation1;
            }
        }
        return reservation;
    }

    //show booking details
    public void showReservations() {
        //shoe message if reservation list is empty
        if (reservations.size() == 0) {
            System.out.println("reservation list is empty");
        } else {
            System.out.println("\n Reservation Details");
            System.out.printf("%-30s%-30s%-30s%-30s%-30s%-30s%-30s%-30s%-30s%-30s%-30s\n", "Reservation No", "Registration Id",
                    "Swimmer Name", "Swimmer Level", "swimming Id", "Class Level", "Status", "Instructor", "Swimming Date", "Swimming Day", "Time Slot\n");
            System.out.println("_______________________________________________________________________________________________________________________________________________________"
                    + "__________________________________________________________________________________________________________________________________________________________________________________________");
            for (ReservationManagement reservation1 : reservations) {
                String swimmerName = swimmer.getSwimmerByid(reservation1.getSwimmer().getRegistrationId()).getFullName();
                int swimmerLevel = swimmer.getSwimmerByid(reservation1.getSwimmer().getRegistrationId()).getGradeLevel();

                System.out.printf("%-30s%-30s%-30s%-30s%-30s%-30s%-30s%-30s%-30s%-30s%-30s\n", "Reserve@_0" + reservation1.getReservationNo(), "Reg@_0" + reservation1.getSwimmer().getRegistrationId(),
                        swimmerName, "Grade " + swimmerLevel, "Swim@_0" + reservation1.getLesson().getSwimmingId(), "Grade " + reservation1.getLesson().getSwimmingLevel(), reservation1.getReservationStatus(),
                        reservation1.getLesson().getSwimmingInstructor(), reservation1.getLesson().getSwimmingDate(), reservation1.getLesson().getSwimmingDay(), reservation1.getLesson().getSwimmingSlot()+"\n");

            }
        }

    }

    //select reservation
    public int selectSwimmer() {
        String selectInput;
        int swimmerId = 0;
        //chech select input
        boolean validSelection = false;
        System.out.println("\nPlese enter one swimmer id from below swimmer list\n");
        //display all swimmer details
        getSwimmerByClassLevel(swimmingId);
        //take input from user by using while loop
        while (!validSelection) {
            //take input from user
            System.out.print("Enter Swimmer Id : ");
            selectInput = scan.nextLine().trim();
            //validation of selectInput
            if (!selectInput.matches("\\d+")) {
                System.out.println("swiimer enter : " + selectInput);
                System.out.println("Invalid choice : Please enter valid swimmer id : ");
                validSelection = false;
            } else {
                //select input change into integer 
                int validSwimmer = Integer.parseInt(selectInput);
                if (validSwimmerId(validSwimmer)) {
                    //set swimmer Id after get valid swiming id
                    swimmerId = validSwimmer;
                    validSelection = true;
                } else {
                    //print error message if swimmer does not exist
                    System.out.println("Error : Swimmer does not exist");
                    validSelection = false;
                }
            }
        }
        return swimmerId;
    }

    //get swimmer list which is match with class level
    public void getSwimmerByClassLevel(int swimmingId) {
        int classLevel = timetable.getSwimmingLessonDetailsById(swimmingId).getSwimmingLevel();
        List<Swimmer> swimmers = swimmer.getSwimmers();
        System.out.printf("%-30s%-30s%-30s%-30s%-30s%-30s\n", "Swimmer Id", "Swimmer Name", "Swimmer Grade", "Swimmer Age", "Swimmer Phone", "Swimmer Gender");
       System.out.println("_________________________________________________________________________________________________________________________________________________________________");
        for (Swimmer swimmer_details : swimmers) {
            if (swimmer_details.getGradeLevel() == classLevel || swimmer_details.getGradeLevel() == (classLevel - 1)) {
                System.out.printf("\n%-30s%-30s%-30s%-30s%-30s%-30s", swimmer_details.getRegistrationId(), swimmer_details.getFullName(),
                        "Grade "+swimmer_details.getGradeLevel(), swimmer_details.getAge()+" year", swimmer_details.getPhone(), swimmer_details.getGender());
                System.out.println();
            }
        }
    }

    //verification of swimming id
    public boolean validSwimmingId(int swimmingId) {
        List<SwimmingLesson> lessons = timetable.getSwimmingLessons();
        for (SwimmingLesson lesson : lessons) {
            if (lesson.getSwimmingId() == swimmingId) {
                return true;
            }
        }
        return false;
    }

    // check valid swimmerId
    public boolean validSwimmerId(int swimmerId) {
        List<Swimmer> swimmers = swimmer.getSwimmers();
        for (Swimmer swimmer_details : swimmers) {
            if (swimmer_details.getRegistrationId() == swimmerId) {
                return true;
            }
        }
        return false;
    }

    //chcek class capacity 
    public boolean classCapacity(int swimmingId) {
        List<SwimmingLesson> lessons = timetable.getSwimmingLessons();
        for (SwimmingLesson lesson1 : lessons) {
            if (lesson1.getSwimmingId() == swimmingId) {
                if (lesson1.getSwimmingCapacity() >= 1 && lesson1.getSwimmingCapacity() <= 5) {
                    return true;
                }
            }
        }
        return false;
    }

    //check duplicate Reservation
    public boolean duplicateReservation(int classId, int registrationId) {
        for (ReservationManagement reservation1 : reservations) {
            if (reservation1.getSwimmer().getRegistrationId() == registrationId && reservation1.getLesson().getSwimmingId() == classId) {
                if (!reservation1.getReservationStatus().equalsIgnoreCase("Cancelled")) {
                    return true;
                }

            }
        }
        return false;
    }

    //check valid reservation no
    public boolean validRegistrationNo(int ReservationNo) {
        for (ReservationManagement reservation1 : reservations) {
            if (reservation1.getReservationNo() == ReservationNo) {
                return true;
            }
        }
        return false;
    }

    //chcek booking id not attend
    public String reservationStatus(int reservationNo) {
        String reservationStatus = null;
        for (ReservationManagement reservation1 : reservations) {
            if (reservation1.getReservationNo() == reservationNo) {
                reservationStatus = reservation1.getReservationStatus();
            }
        }
        return reservationStatus;
    }

    //check swimminglesson level 
    public boolean lessonLevel(int registrationNo, int swimmingId) {
        int classLevel = timetable.getSwimmingLessonDetailsById(swimmingId).getSwimmingLevel();
        int swimmerLevel = swimmer.getSwimmerByid(registrationNo).getGradeLevel();
        return classLevel == swimmerLevel || classLevel == (swimmerLevel + 1);
    }

}
