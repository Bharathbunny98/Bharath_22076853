package swimmingschoommanagement;

import java.util.List;

public class ReportGenerator {

    private Swimmer swimmer;
    private ReviewManagement review;
    private ReservationManagement reservation;

    public ReportGenerator(Swimmer swimmer, ReviewManagement review, ReservationManagement reservation) {
        this.swimmer = swimmer;
        this.review = review;
        this.reservation = reservation;
    }

    public void generateSwimmerReport() {
        int reservationNo;
        int swimmingId;
        String swimmingTitle;
        String date;
        String day;
        String time;
        String instructorName;
        //get swimmer and reservation details from list
        List<Swimmer> swimmers = swimmer.getSwimmers();
        List<ReservationManagement> reservations = reservation.getReservations();

        System.out.println("\nSwimmer Reservations Details\n");
        for (Swimmer currentSwimmer : swimmers) {
            int totalReserved = 0;
            int totalCancelled = 0;
            int totalAttended = 0;
            //get book cancel and attend result by using for loop 
            for (ReservationManagement reservation1 : reservations) {
                if (reservation1.getSwimmer().getRegistrationId() == currentSwimmer.getRegistrationId()) {
                    String status = reservation1.getReservationStatus().toLowerCase();
                    //get total reserved data
                    if (status.equals("booked") || status.equals("changed")) {
                        totalReserved++;
                        //get total cancel data
                    } else if (status.equals("cancelled")) {
                        totalCancelled++;
                        //get total attended data
                    } else if (status.equals("attended")) {
                        totalAttended++;
                    }
                }
            }
            //print swimmer reservation details
            if (totalReserved > 0 || totalCancelled > 0 || totalAttended > 0) {
                System.out.println("=================================================================================================================================================================================================="
                        + "=============================================================================");
                System.out.println("\nSwimmer Name: " + currentSwimmer.getFullName());
                System.out.println("Total Cancelled: " + totalCancelled);
                System.out.println("Total Booked Classes: " + totalReserved);
                System.out.println("Total Attended: " + totalAttended);
                System.out.println();
                  System.out.println("_________________________________________________________________________________________________________________________________________________________________________________________________");
                System.out.printf("%-30s%-30s%-30s%-30s%-30s%-30s%-30s%-30s","Reservation No","Swimming Id","Swimming Title","Status","Swimming Date","Swimming Day","Swimming Slot","Swimming Instructor" );
                  System.out.println();
                //get swimmer reseravation details by using for loop
                for (ReservationManagement reservation1 : reservations) {
                    if (reservation1.getSwimmer().getRegistrationId() == currentSwimmer.getRegistrationId()) {
                        reservationNo = reservation1.getReservationNo();
                        swimmingId = reservation.getReservationDetailByReservationNo(reservationNo).getLesson().getSwimmingId();
                        swimmingTitle = reservation.getReservationDetailByReservationNo(reservationNo).getLesson().getSwimmingTitle();
                        date = reservation.getReservationDetailByReservationNo(reservationNo).getLesson().getSwimmingDate();
                        day = reservation.getReservationDetailByReservationNo(reservationNo).getLesson().getSwimmingDay();
                        time = reservation.getReservationDetailByReservationNo(reservationNo).getLesson().getSwimmingSlot();
                        instructorName = reservation.getReservationDetailByReservationNo(reservationNo).getLesson().getSwimmingInstructor();
                        //print details
                        System.out.printf("%-30s%-30s%-30s%-30s%-30s%-30s%-30s%-30s","Reserve@_0" + reservationNo,"Swim@_0" + swimmingId ,swimmingTitle, reservation1.getReservationStatus(),date,day,time,instructorName);
                       System.out.println();

                    }
                }
            }
        }

    }

    //generate instructor report
    public void generateInstructorReport() {
        //get instructors and reviews details from list
        List<ReviewManagement> reviews = review.getReviews();
        List<Instructor> instructors = new Instructor().getInstructors();
        int reservationNo = 0;
        String instructorName;
        int rating = 0;
        String swimmingTitle;
        String review2;
        String swimmerName;
        String exp;
        //get reting detain of each instructor
        for (Instructor instructor1 : instructors) {
            int totalRatings = 0, count = 0;
            for (ReviewManagement review1 : reviews) {
                reservationNo = review1.getReservationNo();
                //validation  by instructor name
                instructorName = reservation.getReservationDetailByReservationNo(reservationNo).getLesson().getSwimmingInstructor();
                if (instructorName.equalsIgnoreCase(instructor1.getFullName())) {
                    totalRatings += review1.getRating();
                    count++;
                }
            }
            //get experience of instructor by name
            exp = new Instructor().getInstructorDetailsByName(instructor1.getFullName()).getExperiance();
            //validation total ratings is not 0
            if (totalRatings != 0) {
                //print instructor rating details
                System.out.println("==========================================================================================================================");
                double averageRating = (double) totalRatings / count;
                System.out.println("Instructor: " + instructor1.getFullName());
                System.out.println("Average Rating: " + averageRating);
                System.out.println("Experience : " + exp);
                System.out.println();
                System.out.println("___________________________________________________________________________________________________________________________");
                System.out.printf("%-30s%-30s%-30s%-30s%-30s","Rating Id","SwimmingTitle","Rating","Review","Given by");
               
            //get instructor rating details
                for (ReviewManagement review1 : reviews) {
                    reservationNo = review1.getReservationNo();
                    instructorName = reservation.getReservationDetailByReservationNo(reservationNo).getLesson().getSwimmingInstructor();
                    //filter rating by instructor full name
                    if (instructorName.equalsIgnoreCase(instructor1.getFullName())) {
                        swimmingTitle = reservation.getReservationDetailByReservationNo(reservationNo).getLesson().getSwimmingTitle();
                        rating = review1.getRating();
                        review2 = review1.getReview();
                        swimmerName = reservation.getReservationDetailByReservationNo(reservationNo).getSwimmer().getFullName();
                        System.out.printf("%-30s%-30s%-30s%-30s%-30s\n", "Rating@_0" + review1.getRatingId(), swimmingTitle, rating, review2, swimmerName);
                        System.out.println();
                    }
                }
        }
        }
    
    }
}
