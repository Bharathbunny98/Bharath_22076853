package swimmingschoommanagement;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class ReviewManagement {

    private int ratingId;
    private int reservationNo;
    private int rating;
    private String review;
    private Scanner scan;
    private List<ReviewManagement> reviews;

   

    public int getRatingId() {
        return ratingId;
    }

    public void setRatingId(int ratingId) {
        this.ratingId = ratingId;
    }

    public int getReservationNo() {
        return reservationNo;
    }

    public void setReservationNo(int reservationNo) {
        this.reservationNo = reservationNo;
    }

    public int getRating() {
        return rating;
    }

    public void setRating(int rating) {
        this.rating = rating;
    }

    public String getReview() {
        return review;
    }

    public void setReview(String review) {
        this.review = review;
    }
     public List<ReviewManagement> getReviews() {
        return reviews;
    }

    public void setReviews(List<ReviewManagement> reviews) {
        this.reviews = reviews;
    }

    public ReviewManagement(int ratingId, int reservationNo, int rating, String review) {
        this.ratingId = ratingId;
        this.reservationNo = reservationNo;
        this.rating = rating;
        this.review = review;
    }

    public ReviewManagement() {
        scan = new Scanner(System.in);
         reviews = new ArrayList<>();
    }

    //set review after attend class
    public void saveReview(int reservationNo) {
        // generate random rating id
        String ratingInput;
        ratingId = reviews.size() + 1;
        boolean validInput = false;
        // take review details from swimmer after attending the class
        while (!validInput) {
            System.out.print("Give Ratings (1 to 5): ");
            ratingInput = scan.nextLine();
            if (ratingInput.matches("[1-5]")) {
                rating = Integer.parseInt(ratingInput);
                validInput=true;
            } else {
                System.out.println("Invalid Rating :  Please enter a number between 1 and 5.");
            }
           
                 System.out.print("Give Review: ");
                 review = scan.nextLine().trim();
                reviews.add(new ReviewManagement(ratingId, reservationNo, rating, review));
        }
        
        
       
      
    }

    //get review details
    public void showReview(ReservationManagement reservation) {
        int swimmingId;
        String swimmer;
        String swimTitle;
        String instructor;
        String date;
        String day;
        if (reviews.isEmpty()) {
            System.out.println("No reviews available.");
        } else {
            System.out.println("\nReview Details\n");
            System.out.printf("%-30s%-30s%-30s%-30s%-30s%-30s%-30s%-10s%-30s\n","Rating ID","Reservation No",
                    "Swimming Title","Swimmer Name","Instructor Name","Swimming Date","Swimming Day","Rating","Review" );
           System.out.println("___________________________________________________________________________________________"
                   + "_________________________________________________________________________________________________    ");
            
            for (ReviewManagement review1 : reviews) {
                reservationNo = review1.getReservationNo();
                swimmingId = reservation.getReservationDetailByReservationNo(reservationNo).getLesson().getSwimmingId();
                swimTitle =new SwimmingTimeTable().getSwimmingLessonDetailsById(swimmingId).getSwimmingTitle();
                instructor = new SwimmingTimeTable().getSwimmingLessonDetailsById(swimmingId).getSwimmingInstructor();
                date = new SwimmingTimeTable().getSwimmingLessonDetailsById(swimmingId).getSwimmingDate();
                day = new SwimmingTimeTable().getSwimmingLessonDetailsById(swimmingId).getSwimmingDay();
                swimmer = reservation.getReservationDetailByReservationNo(reservationNo).getSwimmer().getFullName();
                //display review details
                System.out.printf("%-30s%-30s%-30s%-30s%-30s%-30s%-30s%-10s%-30s\n","Ratin@_0" + review1.getRatingId(),
                        "Reserve@_0" + reservationNo,swimTitle,swimmer ,instructor,date,day, review1.getRating(),review1.getReview());
               
                System.out.println();
            }
        }
    }

}
