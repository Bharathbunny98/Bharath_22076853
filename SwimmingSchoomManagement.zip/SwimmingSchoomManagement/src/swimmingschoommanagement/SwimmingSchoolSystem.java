package swimmingschoommanagement;

import java.util.Scanner;

public class SwimmingSchoolSystem {

    private ReviewManagement review;
    private SwimmingTimeTable timetable;
    private ReportGenerator report;
    private Swimmer swimmer;
    private ReservationManagement reservation;
    private Scanner scan;

    //create constructor
    public SwimmingSchoolSystem() {
        swimmer = new Swimmer();
        swimmer.preRegisterSwimmer();
        timetable = new SwimmingTimeTable();
        reservation = new ReservationManagement(swimmer, timetable);
        review = new ReviewManagement();
        report = new ReportGenerator(swimmer, review, reservation);
        scan = new Scanner(System.in);
    }

    //take userchoi and call function according to user choice
    public void userChoice() {
        String choice;
        boolean validChoice = false;
        //show option for selecting
        System.out.println("\nA. Add Swimmer\nB. Reserve Class\nC. Change Reserve Class\nD. Cancel Reserve Class "
                + "\nE. Attend Reserve Class  \nF. View Review \nG. Generate Swimmer Report\nH. Generate Instructor Report\nI. View All Reservation\nJ. Exit ");
        while (!validChoice) {
            System.out.print("Enter your choice (Alphabetical order): ");
            choice = scan.nextLine().trim().toUpperCase();
            if (choice.length() == 1 && choice.matches("[A-J]")) {
                validChoice = true;
            } else {
                //print error message
                System.out.println("Invalid choice : Please enter a valid alphabetical choice.");
                continue;
            }
            //call function according to user input
            if (choice.equals("A")) {
                //add new swimmer
                swimmer.addNewSwimmer();
            } else if (choice.equals("B")) {
                //reserve class
                reservation.reserveClass();
            } else if (choice.equals("C")) {
                reservation.changeReservation();
            } else if (choice.equals("D")) {
                reservation.cancelReservation();
            } else if (choice.equals("E")) {
                reservation.attendReserveClass(review);
            } else if (choice.equals("F")) {
                review.showReview(reservation);
            } else if (choice.equals("G")) {
                report.generateSwimmerReport();
            } else if (choice.equals("H")) {
                report.generateInstructorReport();
            } else if (choice.equals("I")) {
                reservation.showReservations();
            } else {
                System.out.println("Thank you");
                System.exit(0);
            }
        }
        userChoice();
    }

    public static void main(String[] args) {
        SwimmingSchoolSystem school = new SwimmingSchoolSystem();
        school.userChoice();

    }
}
