package swimmingschoommanagement;


public class SwimmingLesson {

    private int swimmingId;
    private String swimmingTitle;
    private int swimmingLevel;
    private String swimmingDate;
    private String swimmingDay;
    private String swimmingSlot;
    private String swimmingInstructor;
    private int swimmingCapacity;

    public int getSwimmingId() {
        return swimmingId;
    }

    public void setSwimmingId(int swimmingId) {
        this.swimmingId = swimmingId;
    }

    public String getSwimmingTitle() {
        return swimmingTitle;
    }

    public void setSwimmingTitle(String swimmingTitle) {
        this.swimmingTitle = swimmingTitle;
    }

    public int getSwimmingLevel() {
        return swimmingLevel;
    }

    public void setSwimmingLevel(int swimmingLevel) {
        this.swimmingLevel = swimmingLevel;
    }

    public String getSwimmingDate() {
        return swimmingDate;
    }

    public void setSwimmingDate(String swimmingDate) {
        this.swimmingDate = swimmingDate;
    }

    public String getSwimmingDay() {
        return swimmingDay;
    }

    public void setSwimmingDay(String swimmingDay) {
        this.swimmingDay = swimmingDay;
    }

    public String getSwimmingInstructor() {
        return swimmingInstructor;
    }

    public void setSwimmingInstructor(String swimmingInstructor) {
        this.swimmingInstructor = swimmingInstructor;
    }
    
     public String getSwimmingSlot() {
        return swimmingSlot;
    }

    public void setSwimmingSlot(String swimmingSlot) {
        this.swimmingSlot = swimmingSlot;
    }

    public int getSwimmingCapacity() {
        return swimmingCapacity;
    }

    public void setSwimmingCapacity(int swimmingCapacity) {
        this.swimmingCapacity = swimmingCapacity;
    }

        //create constructor
    public SwimmingLesson(int swimmingId, String swimmingTitle, int swimmingLevel, String swimmingDate, String swimmingInstructor, String swimmingDay,String swimmingSlot, int swimmingCapacity) {
        this.swimmingId = swimmingId;
        this.swimmingTitle = swimmingTitle;
        this.swimmingLevel = swimmingLevel;
        this.swimmingDate = swimmingDate;
        this.swimmingDay = swimmingDay;
        this.swimmingInstructor = swimmingInstructor;
        this.swimmingCapacity = swimmingCapacity;
        this.swimmingSlot=swimmingSlot;

    }

    

   

   

   
    
    
}
