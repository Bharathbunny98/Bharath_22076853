package swimmingschoommanagement;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Scanner;

public class SwimmingTimeTable implements Iterable<SwimmingLesson> {
    private Scanner scan;
    private List<SwimmingLesson> swimmingLessons;

    public List<SwimmingLesson> getSwimmingLessons() {
        return swimmingLessons;
    }

    //create constructor
    public SwimmingTimeTable() {
        scan = new Scanner(System.in);
        swimmingLessons = new ArrayList<>();
        saveLesson();
    }

    //save pre defined lesson
    public void saveLesson() {
        swimmingLessons.add(new SwimmingLesson(1, "Swimming Basics", 1, "18 MAR 2024", "Emily", "Monday", "4:00pm to 5:00pm", 4));
        swimmingLessons.add(new SwimmingLesson(2, "Swimming Basics", 1, "18 MAR 2024", "Emily", "Monday", "5:00pm to 6:00pm", 4));
        swimmingLessons.add(new SwimmingLesson(3, "Advanced Swimming", 5, "18 MAR 2024", "John", "Monday", "6:00pm to 7:00pm", 4));
        swimmingLessons.add(new SwimmingLesson(4, "Intermediate Swimming", 3, "20 MAR 2024", "Sarah", "Wednesday", "4:00pm to 5:00pm", 4));
        swimmingLessons.add(new SwimmingLesson(5, "Intermediate Swimming", 4, "20 MAR 2024", "Sarah", "Wednesday", "5:00pm to 6:00pm", 4));
        swimmingLessons.add(new SwimmingLesson(6, "Intermediate Swimming", 3, "20 MAR 2024", "Michael", "Wednesday", "6:00pm to 7:00pm", 4));
        swimmingLessons.add(new SwimmingLesson(7, "Advanced Swim Techniques", 2, "22 MAR 2024", "Michael", "Friday", "4:00pm to 5:00pm", 4));
        swimmingLessons.add(new SwimmingLesson(8, "Advanced Swim Techniques", 3, "22 MAR 2024", "Michael", "Friday", "5:00pm to 6:00pm", 4));
        swimmingLessons.add(new SwimmingLesson(9, "Advanced Swim Techniques", 2, "22 MAR 2024", "John", "Friday", "6:00pm to 7:00pm", 4));
        swimmingLessons.add(new SwimmingLesson(10, "Dynamic Aqua Exercises", 4, "23 MAR 2024", "Sarah", "Saturday", "2:00pm to 3:00pm", 4));
        swimmingLessons.add(new SwimmingLesson(11, "Dynamic Aqua Exercises", 4, "23 MAR 2024", "John", "Saturday", "3:00pm to 4:00pm", 4));
        swimmingLessons.add(new SwimmingLesson(12, "Agile Aquatic Movements", 1, "25 MAR 2024", "Emily", "Monday", "4:00pm to 5:00pm", 4));
        swimmingLessons.add(new SwimmingLesson(13, "Agile Aquatic Movements", 4, "25 MAR 2024", "Sarah", "Monday", "5:00pm to 6:00pm", 4));
        swimmingLessons.add(new SwimmingLesson(14, "Agile Aquatic Movements", 1, "25 MAR 2024", "John", "Monday", "6:00pm to 7:00pm", 4));
        swimmingLessons.add(new SwimmingLesson(15, "Wave Rider Techniques", 1, "27 MAR 2024", "Emily", "Wednesday", "4:00pm to 5:00pm", 4));
        swimmingLessons.add(new SwimmingLesson(16, "Wave Rider Techniques", 5, "27 MAR 2024", "Michael", "Wednesday", "5:00pm to 6:00pm", 4));
        swimmingLessons.add(new SwimmingLesson(17, "Wave Rider Techniques", 5, "27 MAR 2024", "Michael", "Wednesday", "6:00pm to 7:00pm", 4));
        swimmingLessons.add(new SwimmingLesson(18, "Smart Swimming Strategies", 4, "29 MAR 2024", "Michael", "Friday", "4:00pm to 5:00pm", 4));
        swimmingLessons.add(new SwimmingLesson(19, "Smart Swimming Strategies", 5, "29 MAR 2024", "Sarah", "Friday", "5:00pm to 6:00pm", 4));
        swimmingLessons.add(new SwimmingLesson(20, "Smart Swimming Strategies", 4, "29 MAR 2024", "John", "Friday", "6:00pm to 7:00pm", 4));
        swimmingLessons.add(new SwimmingLesson(21, "Aqua Aerobics", 1, "30 MAR 2024", "Sarah", "Saturday", "2:00pm to 3:00pm", 4));
        swimmingLessons.add(new SwimmingLesson(22, "Aqua Aerobics", 5, "30 MAR 2024", "John", "Saturday", "3:00pm to 4:00pm", 4));
        swimmingLessons.add(new SwimmingLesson(23, "Aquatic Agility", 5, "01 APR 2024", "Michael", "Monday", "4:00pm to 5:00pm", 4));
        swimmingLessons.add(new SwimmingLesson(24, "Aquatic Agility", 2, "01 APR 2024", "Emily", "Monday", "5:00pm to 6:00pm", 4));
        swimmingLessons.add(new SwimmingLesson(25, "Aquatic Agility", 1, "01 APR 2024", "Emily", "Monday", "6:00pm to 7:00pm", 4));
        swimmingLessons.add(new SwimmingLesson(26, "Wave Breaker Strategies", 4, "03 APR 2024", "John", "Wednesday", "4:00pm to 5:00pm", 4));
        swimmingLessons.add(new SwimmingLesson(27, "Wave Breaker Strategies", 3, "03 APR 2024", "John", "Wednesday", "5:00pm to 6:00pm", 4));
        swimmingLessons.add(new SwimmingLesson(28, "Wave Breaker Strategies", 2, "03 APR 2024", "John", "Wednesday", "6:00pm to 7:00pm", 4));
        swimmingLessons.add(new SwimmingLesson(29, "Dynamic Aqua Exercises", 5, "05 APR 2024", "Michael", "Friday", "4:00pm to 5:00pm", 4));
        swimmingLessons.add(new SwimmingLesson(30, "Dynamic Aqua Exercises", 4, "05 APR 2024", "Sarah", "Friday", "5:00pm to 6:00pm", 4));
        swimmingLessons.add(new SwimmingLesson(31, "Strategic Swim Planning", 5, "05 APR 2024", "Michael", "Friday", "6:00pm to 7:00pm", 4));
        swimmingLessons.add(new SwimmingLesson(32, "Aquatic Dynamics", 5, "06 APR 2024", "John", "Saturday", "2:00pm to 3:00pm", 4));
        swimmingLessons.add(new SwimmingLesson(33, "Aquatic Dynamics", 5, "06 APR 2024", "Michael", "Saturday", "3:00pm to 4:00pm", 4));
        swimmingLessons.add(new SwimmingLesson(34, "Agile Aqua Movements", 1, "08 APR 2024", "John", "Monday", "4:00pm to 5:00pm", 4));
        swimmingLessons.add(new SwimmingLesson(35, "Agile Aqua Movements", 4, "08 APR 2024", "Sarah", "Monday", "5:00pm to 6:00pm", 4));
        swimmingLessons.add(new SwimmingLesson(36, "Agile Aqua Movements", 1, "08 APR 2024", "Michael", "Monday", "6:00pm to 7:00pm", 4));
        swimmingLessons.add(new SwimmingLesson(37, "Wave Rider Strategies", 3, "10 APR 2024", "Michael", "Wednesday", "4:00pm to 5:00pm", 4));
        swimmingLessons.add(new SwimmingLesson(38, "Wave Rider Strategies", 2, "10 APR 2024", "John", "Wednesday", "5:00pm to 6:00pm", 4));
        swimmingLessons.add(new SwimmingLesson(39, "Wave Rider Strategies", 1, "10 APR 2024", "Emily", "Wednesday", "6:00pm to 7:00pm", 4));
        swimmingLessons.add(new SwimmingLesson(40, "Smart Swim Techniques", 4, "12 APR 2024", "Emily", "Friday", "4:00pm to 5:00pm", 4));
        swimmingLessons.add(new SwimmingLesson(41, "Smart Swim Techniques", 5, "12 APR 2024", "John", "Friday", "5:00pm to 6:00pm", 4));
        swimmingLessons.add(new SwimmingLesson(42, "Smart Swim Techniques", 1, "12 APR 2024", "Sarah", "Friday", "6:00pm to 7:00pm", 4));
        swimmingLessons.add(new SwimmingLesson(43, "Aqua Agility", 5, "13 APR 2024", "Michael", "Saturday", "2:00pm to 3:00pm", 4));
        swimmingLessons.add(new SwimmingLesson(44, "Aqua Agility", 4, "13 APR 2024", "Sarah", "Saturday", "3:00pm to 4:00pm", 4));
    }

    //display lesson details
    public boolean lessonTimeTable() {
        String result;
        List<SwimmingLesson> modifyLesson = null;
        String filterType = null;
        boolean validChoice = false;
        while (!validChoice) {
            if (filterType == null || filterType.matches("//d+")) {
                System.out.print("Enter your choice to show timetable (All/Grade/Day/Coach/Back) : ");
                filterType = scan.nextLine();
            } else {
                if (filterType.equalsIgnoreCase("All")) {
                    validChoice = true;
                    modifyLesson = swimmingLessons;
                } else if (filterType.equalsIgnoreCase("Grade")) {
                    validChoice = true;
                    modifyLesson = filterLessonsByGrade();
                } else if (filterType.equalsIgnoreCase("Day")) {
                    validChoice = true;
                    modifyLesson = filterLessonsByDay();
                } else if (filterType.equalsIgnoreCase("Coach")) {
                    validChoice = true;
                    modifyLesson = filterLessonsByInstructor();
                } else if (filterType.equalsIgnoreCase("Back")) {
                    return true;
                } else {
                    //set valid choice false if not enter valid choice
                    validChoice = false;
                    filterType = null;
                }
            }
        }
        if (!filterType.equalsIgnoreCase("Back")) {
            showTimeTable(modifyLesson);
        }

        return false;
    }
    
    //show filter time table
    public void showTimeTable(List<SwimmingLesson> modifyLesson) {
        String instructorExp;
        System.out.printf("\n%-30s%-30s%-30s%-30s%-30s%-30s%-30s%-30s%-30s\n","Swimming Id","Swimming Title","Swimming Level","Date","Day","Instructor","Instructor Experience","Capacity","Swimming Slot\n");
       System.out.println("______________________________________________________________________________________________________________________________________________________________________________________________________________________________________________________________________________");
        for (SwimmingLesson lesson1 : modifyLesson) {
            //get coach experiece by name
            instructorExp=new Instructor().getInstructorDetailsByName(lesson1.getSwimmingInstructor()).getExperiance();
            System.out.printf("%-30s%-30s%-30s%-30s%-30s%-30s%-30s%-30s%-30s\n","Swim@_0" + lesson1.getSwimmingId(),lesson1.getSwimmingTitle(),"Grade " + lesson1.getSwimmingLevel(),
            lesson1.getSwimmingDate(),lesson1.getSwimmingDay(),lesson1.getSwimmingInstructor(),instructorExp,lesson1.getSwimmingCapacity(),lesson1.getSwimmingSlot());
            System.out.println();
        }
    }
    
    
    

    // filter lessons by grade
    public List<SwimmingLesson> filterLessonsByGrade() {
        String grade = null;
        boolean validGrade = false;
        List<SwimmingLesson> lesson2 = new ArrayList<>();
        while (!validGrade) {
            System.out.print("Enter Grade (1 to 5 ) : ");
            grade = scan.nextLine();
            if (grade == null || !grade.matches("[1-5]")) {
                validGrade = false;
                System.out.println("Invalid choice : Please enter valid numerical grade");
            } else {
                for (SwimmingLesson lesson1 : swimmingLessons) {
                    if (lesson1.getSwimmingLevel() == Integer.parseInt(grade)) {
                        lesson2.add(lesson1);
                        validGrade = true;
                    }
                }
                if (!validGrade) {
                    //print error message
                    System.out.println("Invalid choice : Selected grade does not exist");
                }
            }
        }
        return lesson2;
    }

    // filter lessons by coach
    public List<SwimmingLesson> filterLessonsByInstructor() {
        String instructor = null;
        boolean validInstructor = false;
        List<SwimmingLesson> lesson2 = new ArrayList<>();
        while (!validInstructor) {
            List<Instructor> instructors = new Instructor().getInstructors();
            System.out.print("Enter Instructor Name (");
            for (Instructor instructor1 : instructors) {
                System.out.print("/" + instructor1.getFullName());
            }
            System.out.print(") : ");
            instructor = scan.nextLine();
            if (instructor == null || instructor.matches("//d+")) {
                System.out.println("Invalid choice : Please enter valid instructor name");
                validInstructor = false;
            } else {
                for (SwimmingLesson lesson1 : swimmingLessons) {
                    if (lesson1.getSwimmingInstructor().equalsIgnoreCase(instructor)) {
                        lesson2.add(lesson1);
                        validInstructor = true;
                    }
                }
                if (!validInstructor) {

                    System.out.println("Invalid choice : Selected Instructor does not exist");
                }
            }
        }
        return lesson2;
    }

    // Method to filter lessons by day
    public List<SwimmingLesson> filterLessonsByDay() {
        String day = null;
        boolean validDay = false;
        List<SwimmingLesson> lesson2 = new ArrayList<>();
        while (!validDay) {
            System.out.print("Enter Day (Monday/Wednesday/Friday/Saturday) : ");
            day = scan.nextLine();
            if (day == null || day.matches("//d+")) {
                System.out.println("Invalid choice : Please enter valid day name(Ex : Monday or Mon) ");
                validDay = false;
            } else {
                validDay = false;
                for (SwimmingLesson lesson1 : swimmingLessons) {
                    if (lesson1.getSwimmingDay().equalsIgnoreCase(day) || lesson1.getSwimmingDay().substring(0, 3).equalsIgnoreCase(day)) {
                        lesson2.add(lesson1);
                        validDay = true;
                    }
                }
                if (!validDay) {

                    System.out.println("Invalid choice : Selected day does not exist ");
                }
            }
        }
        return lesson2;
    }

    //get class details by swimmingId
    public SwimmingLesson getSwimmingLessonDetailsById(int swimmingId) {
        SwimmingLesson swim = null;
        for (SwimmingLesson lesson : swimmingLessons) {
            if (lesson.getSwimmingId() == swimmingId) {
                swim = lesson;
            }
        }
        return swim;
    }

    //public seat modify after reservation
    public void seatModify(int swimmingId, String status) {
        int currentCapacity = 0;
        for (SwimmingLesson swimmingLessonList : swimmingLessons) {
            if (swimmingLessonList.getSwimmingId() == swimmingId) {
                //get current lesson capacity
                currentCapacity = swimmingLessonList.getSwimmingCapacity();
                //modify seat after reserved class
                if (status.equalsIgnoreCase("Booked")) {
                    swimmingLessonList.setSwimmingCapacity(currentCapacity - 1);
                    break;
                    //modify capacity after cancelled class
                } else if (status.equalsIgnoreCase("Cancelled")) {
                    swimmingLessonList.setSwimmingCapacity(currentCapacity + 1);
                    break;
                    //modify capacity after attended class
                } else if (status.equalsIgnoreCase("Attended")) {
                    swimmingLessonList.setSwimmingCapacity(currentCapacity + 1);
                    break;
                }
            }
        }
    }

    @Override
    public Iterator<SwimmingLesson> iterator() {
        return swimmingLessons.iterator();
    }

}
