package swimmingschoommanagement;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

class Swimmer {

    private Scanner scan;
    private int registrationId;
    private String fullName;
    private String gender;
    private int age;
    private String phone;
    private int gradeLevel;
    private final int minAge = 4;
    private final int maxAge = 11;
    private final int minGrade = 1;
    private final int maxGrade = 5;
    private List<Swimmer> swimmers;

    public int getRegistrationId() {
        return registrationId;
    }

    public void setRegistrationId(int registrationId) {
        this.registrationId = registrationId;
    }

    public String getFullName() {
        return fullName;
    }

    public void setFullName(String fullName) {
        this.fullName = fullName;
    }

    public String getGender() {
        return gender;
    }

    public void setGender(String gender) {
        this.gender = gender;
    }

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public int getGradeLevel() {
        return gradeLevel;
    }

    public void setGradeLevel(int gradeLevel) {
        this.gradeLevel = gradeLevel;
    }

    //get all swimmer details
    public List<Swimmer> getSwimmers() {
        return swimmers;
    }

    public void setSwimmers(List<Swimmer> swimmers) {
        this.swimmers = swimmers;
    }

    public Swimmer(int registrationId, String fullName, String gender, int age, String phone, int gradeLevel) {
        this.registrationId = registrationId;
        this.fullName = fullName;
        this.gender = gender;
        this.age = age;
        this.phone = phone;
        this.gradeLevel = gradeLevel;
    }

    public Swimmer() {
        scan = new Scanner(System.in);
        swimmers = new ArrayList<>();
        preRegisterSwimmer();
    }

    //add 6 pre register swimmer
    public void preRegisterSwimmer() {
        if (swimmers.isEmpty()) {
            swimmers.add(new Swimmer(1, "Alice", "Female", 5, "1234567890", 5));
            swimmers.add(new Swimmer(2, "Bob", "Male", 9, "0987654321", 1));
            swimmers.add(new Swimmer(3, "Charlie", "Male", 7, "1122334455", 2));
            swimmers.add(new Swimmer(4, "Diana", "Female", 4, "5544332211", 3));
            swimmers.add(new Swimmer(5, "Eva", "Female", 11, "9988776655", 4));
            swimmers.add(new Swimmer(6, "Frank", "Male", 10, "6677889900", 1));
        }
    }

    //add new Swimmer details
    public void addNewSwimmer() {
        String swimmerName = null;
        String swimmerGender = null;
        String gender = null;
        int swimmerAge = 0;
        String swimmerPhone = null;
        int swimmerGrade = 0;
        boolean validInput = false;
        boolean nameExist = false;
       System.out.println();
        while (!validInput) {
            if (swimmerName == null || swimmerName.equalsIgnoreCase("") || nameExist) {
                System.out.print("Swimmer Name : ");
                swimmerName = scan.nextLine();
                nameExist = swimmerNameExist(swimmerName);
                if (swimmerName.length() == 0) {
                    System.out.println("Invalid input : Swimmer name cannot be empty");
                } else if (nameExist) {
                    System.out.println("Invalid input : swimmer name already added");
                }
            } else if (swimmerGender == null || !(swimmerGender.equals("1") || swimmerGender.equals("1")
                    || swimmerGender.equalsIgnoreCase("Male") || swimmerGender.equalsIgnoreCase("M")
                    || swimmerGender.equalsIgnoreCase("Female") || swimmerGender.equalsIgnoreCase("F"))) {
                System.out.println("Select one gender from below list ");
                System.out.println("1.Male\n2.Female");
                System.out.print("Enter your choice : ");
                swimmerGender = scan.nextLine();
                if (!(swimmerGender.equals("1") || swimmerGender.equals("1")
                    || swimmerGender.equalsIgnoreCase("Male") || swimmerGender.equalsIgnoreCase("M")
                    || swimmerGender.equalsIgnoreCase("Female") || swimmerGender.equalsIgnoreCase("F"))) {
                    System.out.println("Invalid input : Please select valid gender ");
                }
            } else if (swimmerAge == 0 || swimmerAge < minAge || swimmerAge > maxAge) {
                System.out.print("Age (" + minAge + " to " + maxAge + "year) : ");
                String ageInput = scan.nextLine();
                if (ageInput.matches("\\d+")) {
                    int validAge = Integer.parseInt(ageInput);
                    if (validAge >= minAge && validAge <= maxAge) {
                        swimmerAge = validAge;
                    } else {
                        System.out.println("Invalid input : Swimmer age should be " + minAge + " to " + maxAge + " year");
                    }
                } else {
                    System.out.println("Invalid input : Swimmer age should be " + minAge + " to " + maxAge + " year");
                }
            } else if (swimmerGrade == 0 || swimmerGrade < minGrade || swimmerGrade > maxGrade) {
                System.out.print("Enter grade (" + minGrade + " to " + maxGrade + "): ");
                String gradeInput = scan.nextLine();
                if (gradeInput.matches("\\d")) {
                    int validGrade = Integer.parseInt(gradeInput);
                    if (validGrade >= minGrade && validGrade <= maxGrade) {
                        swimmerGrade = validGrade;
                    } else {
                        System.out.println("Invalid input : grade should be " + minGrade + " to " + maxGrade);
                    }
                } else {
                    System.out.println("Invalid input : grade should be " + minGrade + " to " + maxGrade);
                }
            } else if (swimmerPhone == null || !swimmerPhone.matches("\\d+")) {
                System.out.print("Emergency Contact : ");
                swimmerPhone = scan.nextLine();
                if (!swimmerPhone.matches("\\d+")) {
                    System.out.println("Invalid input : Please enter valid emergency contact number");
                }
            } else {
                validInput = true;
            }
        }
        int registerId = swimmers.size() + 1;
        if (swimmerGender.equalsIgnoreCase("M")||swimmerGender.equalsIgnoreCase("Male")||swimmerGender.equalsIgnoreCase("1")) {
            gender = "Male";
        } else if (swimmerGender.equalsIgnoreCase("F")||swimmerGender.equalsIgnoreCase("Female")||swimmerGender.equalsIgnoreCase("2")) {
            gender = "Female";
        }
        swimmers.add(new Swimmer(registerId, swimmerName, gender, swimmerAge, swimmerPhone, swimmerGrade));
        System.out.println("\nNew swimmer added successfully");
    
    }

    //get swimmer details by their id
    public Swimmer getSwimmerByid(int registerId) {
        Swimmer swim1 = null;
        for (Swimmer swim : swimmers) {
            if (swim.getRegistrationId() == registerId) {
                swim1 = swim;
            }
        }
        return swim1;
    }

    //check name not already exist 
    public boolean swimmerNameExist(String name) {
        for (Swimmer swimmer1 : swimmers) {
            if (swimmer1.getFullName().equalsIgnoreCase(name)) {
                return true;
            }
        }
        return false;

    }

}
