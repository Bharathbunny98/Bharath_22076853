package swimmingschoommanagement;

import java.util.ArrayList;
import java.util.List;

public class Instructor {

    private int uniqueId;
    private String fullName;
    private String contactDetails;
    private String gender;
    private String age;
    private String experiance;
    private List<Instructor> instructors = new ArrayList<>();

    public int getUniqueId() {
        return uniqueId;
    }

    public void setUniqueId(int uniqueId) {
        this.uniqueId = uniqueId;
    }

    public String getFullName() {
        return fullName;
    }

    public void setFullName(String fullName) {
        this.fullName = fullName;
    }

    public String getContactDetails() {
        return contactDetails;
    }

    public void setContactDetails(String contactDetails) {
        this.contactDetails = contactDetails;
    }

    public String getGender() {
        return gender;
    }

    public void setGender(String gender) {
        this.gender = gender;
    }

    public String getAge() {
        return age;
    }

    public void setAge(String age) {
        this.age = age;
    }

    public String getExperiance() {
        return experiance;
    }

    public void setExperiance(String experiance) {
        this.experiance = experiance;
    }

    public Instructor(int uniqueId, String fullName, String contactDetails, String gender, String age, String experiance) {
        this.uniqueId = uniqueId;
        this.fullName = fullName;
        this.contactDetails = contactDetails;
        this.gender = gender;
        this.age = age;
        this.experiance = experiance;
    }

    public Instructor() {
        addInstructor();
    }

    // add new instructor
    public void addInstructor() {
        instructors.add(new Instructor(1, "John", "1234567890", "Male", "35", "5 year"));
        instructors.add(new Instructor(2, "Sarah", "0987654321", "Female", "27", "4 year"));
        instructors.add(new Instructor(3, "Michael", "1122334455", "Male", "29", "3 year"));
        instructors.add(new Instructor(4, "Emily", "5544332211", "Female", "47", "2 year"));
    }
    
    //get instructor details by name
    public Instructor getInstructorDetailsByName(String Name) {
        Instructor instructor = null;
        for (Instructor instructor1 : instructors) {
            if (instructor1.getFullName().equalsIgnoreCase(Name)) {
                instructor = instructor1;
            }
        }
        return instructor;

    }

    //get all coach details
    public List<Instructor> getInstructors() {
        return instructors;
    }

}
