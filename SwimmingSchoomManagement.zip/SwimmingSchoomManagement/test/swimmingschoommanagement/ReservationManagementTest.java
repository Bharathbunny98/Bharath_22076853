package swimmingschoommanagement;

import java.util.ArrayList;
import java.util.List;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

public class ReservationManagementTest {

    private ReservationManagement reservation;
    private SwimmingTimeTable timetable;
    private Swimmer swimmer;
    private ReviewManagement review;

    public ReservationManagementTest() {
        timetable = new SwimmingTimeTable();
        reservation = new ReservationManagement(new Swimmer(), new SwimmingTimeTable());
        review = new ReviewManagement();
        reserveClass();
        swimmer = new Swimmer();

    }

    @BeforeClass
    public static void setUpClass() {
    }

    @AfterClass
    public static void tearDownClass() {
    }

    @Before
    public void setUp() {
    }

    @After
    public void tearDown() {
    }

    @Test
    public void testChangeReservation() {
        int reservationNo = 1;
        int newSwimmingId = 16;
        int previousSwimmingId = reservation.getReservationDetailByReservationNo(reservationNo).getLesson().getSwimmingId();
        int registrationId = reservation.getReservationDetailByReservationNo(reservationNo).getSwimmer().getRegistrationId();
        boolean validReservationNo = reservation.validRegistrationNo(reservationNo);
        boolean validSwimmingId = reservation.validSwimmingId(newSwimmingId);
        boolean validSwimmingLevel = reservation.lessonLevel(registrationId, newSwimmingId);
        String status = "Changed";
        String expResult="Changed";
        SwimmingLesson lesson = new SwimmingTimeTable().getSwimmingLessonDetailsById(newSwimmingId);
        //check given registration no is correct
        if (!validReservationNo) {
            System.err.println("Invalid : Please enter correct reservationNo");
        } else {
            //check valid swimming id
            if (!validSwimmingId) {
                System.err.println("Error : Please enter valid swimming id");

            } else {
                if (!validSwimmingLevel) {
                    System.err.println("Error : This class is not your level select another class");

                } else {
                    List<ReservationManagement> reservations = reservation.getReservations();
                    for (ReservationManagement reservation1 : reservations) {
                        if (reservation1.getReservationNo() == reservationNo) {
                            reservation1.setLesson(lesson);
                            reservation1.setReservationStatus("Changed");
                            break;
                        }
                    }
                    //update class capacity
                    timetable.seatModify(previousSwimmingId, "Cancelled");
                    timetable.seatModify(newSwimmingId, "Booked");
                    System.out.println("Class changed successfully");
                    //display reservation details after change
                }
            }
        }
        String result=reservation.getReservationDetailByReservationNo(reservationNo).getReservationStatus();
        assertEquals(expResult,result);
    }

    @Test
    public void attendReserveClass() {
        int reservationNo = 1;
        int swimmingId;
        int registrationId;
        int lessonLevel;
        int swimmerLevel;
        String expResult="Attended";
        boolean validReservationNo = reservation.validRegistrationNo(reservationNo);
        if (validReservationNo) {
            String reservationStatus = reservation.reservationStatus(reservationNo);
            if (reservationStatus.equalsIgnoreCase("Cancelled")) {
                System.err.println("Selected class already Cancelled");
            } else if (reservationStatus.equalsIgnoreCase("Attended")) {
                System.err.println("Selected class already Attended");
            } else {
                List<ReservationManagement> reservations = reservation.getReservations();
                for (ReservationManagement reservation1 : reservations) {
                    if (reservation1.getReservationNo() == reservationNo) {
                        //show attended class details
                        reservation.showAttendClassDetails(reservationNo);
                        //get review after attended class
                        saveReview(reservationNo);
                        reservation1.setReservationStatus("Attended");
                        //modify capacity after cancel class
                        swimmingId = reservation1.getLesson().getSwimmingId();
                        timetable.seatModify(swimmingId, "Attended");
                        System.out.println("Reservation attended successfully");
                        //modify student level after attend higher class
                        swimmerLevel = reservation1.getSwimmer().getGradeLevel();
                        registrationId = reservation1.getSwimmer().getRegistrationId();
                        lessonLevel = reservation1.getLesson().getSwimmingLevel();
                        if (lessonLevel > swimmerLevel) {
                            //modiify swimmer level
                            List<Swimmer> swimmers = swimmer.getSwimmers();;
                            for (Swimmer swimmer1 : swimmers) {
                                if (swimmer1.getRegistrationId() == registrationId) {
                                    swimmer1.setGradeLevel(lessonLevel);
                                    break;
                                }
                            }
                        }
                       
                    }
                }
            }
        } else {
            System.err.println("Error : reservation no does not exist");
        }
        String result=reservation.getReservationDetailByReservationNo(reservationNo).getReservationStatus();
         assertEquals(expResult,result);

    }

    @Test
    public void testCancelReservation() {
        int reservationNo = 1;
        String status = reservation.reservationStatus(reservationNo);
        int swimmingId;
        String expResult="Cancelled";
        boolean validReservationNo = reservation.validRegistrationNo(reservationNo);
        if (!validReservationNo) {
            System.err.println("Selected reservation no does not exist");
        } else if (status.equalsIgnoreCase("Cancelled")) {
            System.err.println("Selected class already Cancelled");
        } else if (status.equalsIgnoreCase("Attended")) {
            System.err.println("Selected class already Attended");
        } else {
            List<ReservationManagement> reservations = reservation.getReservations();
            for (ReservationManagement reservation1 : reservations) {
                if (reservation1.getReservationNo() == reservationNo) {
                    reservation1.setReservationStatus("Cancelled");
                    //modify capacity after cancel class
                    swimmingId = reservation1.getLesson().getSwimmingId();
                    timetable.seatModify(swimmingId, "Cancelled");
                    System.out.println("Reservation cancelled successfully");
                    break;
                }
            }
        }
        String result=reservation.getReservationDetailByReservationNo(reservationNo).getReservationStatus();
         assertEquals(expResult,result);

    }

    @Test
    public void testDuplicateBooking() {
        int registrationNo = 1;
        int swimmingId = 3;
        boolean expResult=true;
        boolean result = reservation.duplicateReservation(swimmingId, registrationNo);
       assertEquals(expResult,result);
        
    }
    
    @Test
    public void testFilterLessonsByDay() {
        String day = "Monday";
        if (day.equalsIgnoreCase("Monday") || day.equalsIgnoreCase("Wednesday") || day.equalsIgnoreCase("Friday") || day.equalsIgnoreCase("Saturday")) {
            //create arrayList to store filter lesson details
            List<SwimmingLesson> filterLesson = new ArrayList<>();
            List<SwimmingLesson> lessons = timetable.getSwimmingLessons();
            for (SwimmingLesson lesson1 : lessons) {
                if (lesson1.getSwimmingDay().equalsIgnoreCase(day) || lesson1.getSwimmingDay().substring(0, 3).equalsIgnoreCase(day)) {
                    filterLesson.add(lesson1);
                }
            }
            assertNotNull(filterLesson);
            System.out.println("Show time table of monday\n");
            //show filterlesson details
            timetable.showTimeTable(filterLesson);

        } else {
            System.err.println("Error : Please enter valid day (Monday/Wednesday,Friday/Saturday)");
        }
    }
    
    
    
    

    //reserved default class
    public void reserveClass() {
        int reservationNo = reservation.getReservations().size() + 1;
        int registrationNo = 1;
        int swimmingId = 3;
        String status = "Booked";
        Swimmer swimmer1 = new Swimmer().getSwimmerByid(registrationNo);
        SwimmingLesson lesson = timetable.getSwimmingLessonDetailsById(swimmingId);
        List<ReservationManagement> reservations = new ArrayList<>();
        reservations.add(new ReservationManagement(swimmer1, lesson, reservationNo, status));
        reservation.setReservations(reservations);

    }

    //save default review after attend class
    public void saveReview(int reservationNo) {
        int ratingId = review.getReviews().size() + 1;
        int rating = 5;
        String review1 = "";
        if (rating >= 1 && rating <= 5) {
            //create arraylist to save reviews 
            List<ReviewManagement> reviews = new ArrayList<>();
            //save reveiw details in arraylist
            reviews.add(new ReviewManagement(ratingId, reservationNo, rating, review1));
            review.setReviews(reviews);

        } else {
            System.err.println("Error : Give valid rating 1 to 5");
        }

    }

}
